Contenidos de cada carpeta :

	- En la carpeta Code: una carpeta llamada ASM y otra C, donde se
	encuentran las implementaciones de kNN y PCA en ASM y C, respectivamente.

	- En la carpeta Data: 60.000 imágenes de entrenamiento y 10.000 de testing.
	Incluye README.md que detalla el formato de la base de datos.

	- En la carpeta Test all: códigos para testear toda la base de datos con
		- kNN en ASM
		- kNN en C con O3
		- kNN en C sin O3
		- PCA en ASM
		- PCA en C con O3
		- PCA en C sin  O3
	definidos en su respectivo Makefile;
	todos los resultados van a la carpeta Output.

	- En la carpeta Test one img: códigos para testear una sola 
	imagen de todas las de entrenamiento, para kNN y PCA en ASM o C, 
	con sus respectivos Makefiles. El resultado va a la carpeta 
	Output; en este caso además se reconstruye la imagen que 
	estamos testeando en formato .pgm para poder visualizarla.
