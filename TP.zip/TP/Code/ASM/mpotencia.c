#ifndef __M_POT__
#define __M_POT__

#include "defines.h"
#include <math.h>

// Multiplicar vector por vector
float mult_vectorial(float* v1, float* v2){
	return mult_vectorial_ASM(v1, v2);
}

float mult_vectorial2(float* v1, u_int8_t* v2){
	return mult_vectorial2_ASM(v1, v2);
}

// Multiplicar M por vector (res:= M*v)
void mult_matricial(float* v, float* res){
    float temp[entry_size];
	for(int coordenada=0; coordenada<entry_size; coordenada++)
		temp[coordenada] = mult_vectorial(M[coordenada], v);
	copiar_ASM(res, temp);
}
	
void normalizar(float* v){
	dividir_ASM(v, norma2_ASM(v));
}

/* Toma una cantidad de iteraciones y computa 
 * el 1er autovector de M luego de hacer 
 * #iteraciones del met de la potencia */
void mpotencia(int iteraciones, float* res){
	// Arbitrariamente empiezo con todos 1's
	fijar_ASM(res, 1.0);	
	// Hago #iteraciones res := M*res
	for(int i=0; i<iteraciones; i++)
		mult_matricial(res, res), normalizar(res);
}

// Autovalor asociado al autovector v de M
float eigenvalue(float* v){
	float temp[entry_size];
	copiar_ASM(temp, v); // temp = v
	mult_matricial(temp, temp); // temp = M*v
	return mult_vectorial(v, temp); // v^t*M*v = v^t*(M*v)
}

void mpotencia_con_deflacion(){
    for(int i=0; i<alpha; i++){
		// Calculo el i-esimo autovector
		mpotencia(100, M_eigenvectors[i]); 
		// Deflacion en M
		float lambda = eigenvalue(M_eigenvectors[i]);
		// M[i][j] -= lambda*v_i*v_j
		for(int row=0; row<entry_size; row++){
			float escalar = lambda * M_eigenvectors[i][row];
			restar_por_escalar_ASM(M[row], escalar, M_eigenvectors[i]);
		}
	}
}

#endif	/* !__M_POT__ */
