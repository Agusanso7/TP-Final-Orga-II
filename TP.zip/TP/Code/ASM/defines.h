#ifndef __DEFINES_H__
#define __DEFINES_H__

extern float dif_PCA_ASM(float* a, float* b, int alpha);
extern float dif_ASM(u_int8_t* a, u_int8_t* b);
extern float mult_vectorial_ASM(float* v1, float* v2);
extern void copiar_ASM(float* destino, float* origen);
extern void dividir_ASM(float* v, float d);
extern void multiplicar_ASM(float* v, float d);
extern void fijar_ASM(float* v, float x);
extern void restar_por_escalar_ASM(float* a, float x, float* b);
extern float norma2_ASM(float* v);
extern float mult_vectorial2_ASM(float* v1, u_int8_t* v2);
extern void sumar2_ASM(float* a, u_int8_t* b);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define test_size 10000
#define train_size 60000
#define entry_size 784
#define height 28
#define width 28
#define max_alpha entry_size

struct info{
    int index; //Indice en la base de datos
    u_int8_t entry[entry_size]; //Data de la img de 28*28
    int value; //Que numero dice la img
    float dif_actual; //Que tan lejos esta esta img
    float entry_PCA[max_alpha]; // tc(entry)
} train_data[train_size], test_data[test_size];

int alpha;
float mu[entry_size];
float X_transpose[entry_size][train_size];
float M[entry_size][entry_size];
float M_eigenvectors[max_alpha][entry_size];

#endif	/* !__DEFINES_H__ */