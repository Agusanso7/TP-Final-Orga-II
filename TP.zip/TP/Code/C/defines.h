#ifndef __DEFINES_H__
#define __DEFINES_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define test_size 10000
#define train_size 60000
#define entry_size 784
#define height 28
#define width 28
#define max_alpha entry_size

struct info{
    int index; //Indice en la base de datos
    u_int8_t entry[entry_size]; //Img de 28*28 original
    int value; //Que numero representa la img
    float dif_actual; //Que tan lejos esta esta img
    float entry_PCA[max_alpha]; // tc(entry)
} train_data[train_size], test_data[test_size];

int alpha;
float mu[entry_size];
float X_transpose[entry_size][train_size];
float M[entry_size][entry_size];
float M_eigenvectors[max_alpha][entry_size];

#endif	/* !__DEFINES_H__ */