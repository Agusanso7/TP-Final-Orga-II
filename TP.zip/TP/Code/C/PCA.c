#ifndef __PCA__
#define __PCA__

#include "defines.h"
#include "mpotencia.c"
#include "kNN.c"

void compute_mu(){
    for(int i=0; i<entry_size; i++) mu[i]=0.0;
    for(int entry=0; entry<train_size; entry++){
        //Sumo esta entry
        for(int i=0; i<entry_size; i++){
            mu[i] += (float)train_data[entry].entry[i];
        }
    }
}

void compute_X_transpose(){
    compute_mu();
    for(int row=0; row<train_size; row++){
        for(int col=0; col<entry_size; col++){
            X_transpose[col][row] = train_data[row].entry[col] - mu[col];
        }
    }
}

void compute_M(){
    compute_X_transpose();
    for(int i=0; i<entry_size; i++){
        for(int j=0; j<entry_size; j++){
            /* M[i][j] = fila i de X_transpose * col j de X
                      == fila i de X_transpose * fil j de X_transpose */
            float num = mult_vectorial( X_transpose[i], X_transpose[j] );
            M[i][j] = num/(train_size-1);
        }
    }
}

void compute_M_eigenvectors(){
    compute_M();
    //Compute alpha firsts eigenvectors of M
    mpotencia_con_deflacion();
}

//Computes tc(x) forall x in the train_data 
void apply_tc(){
    compute_M_eigenvectors();
    for(int i=0; i<train_size; i++){
        for(int a=0; a<alpha; a++){
            train_data[i].entry_PCA[a] = mult_vectorial2( M_eigenvectors[a], train_data[i].entry );
        }
    }
    for(int i=0; i<test_size; i++){
        for(int a=0; a<alpha; a++){
            test_data[i].entry_PCA[a] = mult_vectorial2( M_eigenvectors[a], test_data[i].entry );
        }
    }
}

#endif	/* !__PCA__ */