#ifndef __M_POT__
#define __M_POT__

#include "defines.h"
#include <math.h>

// Multiplicar vector por vector
float mult_vectorial(float* v1, float* v2){
	float res = 0; 
	for(int i=0; i<entry_size; i++)
		res += v1[i] * v2[i];
	return res;
}

float mult_vectorial2(float* v1, u_int8_t* v2){
	float res = 0; 
	for(int i=0; i<entry_size; i++)
		res += v1[i] * v2[i];
	return res;
}

// Multiplicar M por vector
void mult_matricial(float* v, float* res){
    float temp[entry_size];
	for(int coordenada=0; coordenada<entry_size; coordenada++)
		temp[coordenada] = mult_vectorial(M[coordenada], v);
	for(int i=0; i<entry_size; i++)
        res[i] = temp[i];
}
	
void normalizar(float* v){
	float norma2 = sqrtf(mult_vectorial(v, v));
    for(int i=0; i<entry_size; i++)
        v[i] /= norma2;
}

/* Toma una cantidad de iteraciones y computa 
 * el autovector de M luego de hacer #iteraciones 
 * del met de la potencia */
void mpotencia(int iteraciones, float* res){
	// Empiezo con nros random
	for(int i=0; i<entry_size; i++)
		res[i] = 1.0;//rand();
			
	// Hago #iteraciones
	for(int i=0; i<iteraciones; i++)
		mult_matricial(res, res), normalizar(res);
}

// Autovalor asociado al autovector v de M
float eigenvalue(float* v){
	float temp[entry_size];
	for(int i=0; i<entry_size; i++) temp[i]=v[i];
	//temp = v
	mult_matricial(temp, temp);
	//temp = M*v
	return mult_vectorial(v, temp);
	//v^t*M*v = v^t*(M*v)
}

void mpotencia_con_deflacion(){
    for(int i=0; i<alpha; i++){
		// Calculo el i-esimo autovector
		mpotencia(100, M_eigenvectors[i]); 
		// Deflacion en M
		float lambda = eigenvalue(M_eigenvectors[i]);
		////printf("%0.5f\n", lambda);
		//M[i][j] -= lambda*v_i*v_j
		for(int row=0; row<entry_size; row++){
			for(int col=0; col<entry_size; col++)
				M[row][col] -= lambda*( M_eigenvectors[i][row]*M_eigenvectors[i][col] );
		}
	}
}

#endif	/* !__M_POT__ */
