#ifndef __UTILS__
#define __UTILS__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defines.h"

void load_data(struct info* data, char* type){
    
    FILE *data_file; int imgs;
    if( type == "test" ){
        data_file = fopen("../../Data/test_entries.txt", "r");
        imgs = test_size;
    }else{
        data_file = fopen("../../Data/train_entries.txt", "r");
        imgs = train_size;
    }
    if( data_file == NULL ){
      perror("Error while opening the file.\n");
      exit(EXIT_FAILURE);
    }

    for(int actual = 0; actual<imgs; actual++){
        fscanf(data_file, "%d", &data[actual].value);
        data[actual].index = actual+1;
        for(int i=0; i<height; i++){ 
            for(int j=0; j<width; j++){ 
                fscanf(data_file, "%hhd", &data[actual].entry[i*width+j]);                
            } 
        } 
    } 
    fclose(data_file);
}

void reconstruct_image(int img_nr){
    if(img_nr<1 || img_nr>test_size){
        perror("Number of test img must be  1 and 10000.\n");
        exit(EXIT_FAILURE);
    }
    char str[40], st[40];
    sprintf(str, "../../Output/%dindex_", img_nr--);
    sprintf(st, "%d", test_data[img_nr].value);
    strcat(st, "value.pgm");
    strcat(str, st);

    FILE* pgmimg; 
    pgmimg = fopen(str, "wb");
  
    fprintf(pgmimg, "P2\n");//Magic Number  
    fprintf(pgmimg, "%d %d\n", width, height);//Width and Height 
    fprintf(pgmimg, "255\n");//Max gray value  
    for(int i=0; i<height; i++){ 
        for(int j=0; j<width; j++){ 
            fprintf(pgmimg, "%d ", test_data[img_nr].entry[i*width+j]); 
        } 
        fprintf(pgmimg, "\n"); 
    } 
    fclose(pgmimg); 
}

int comp(const void *a, const void *b){
    if ( (*(struct info*)a).dif_actual > (*(struct info*)b).dif_actual ) return  1;
    return -1;
}

#endif	/* !__UTILS__ */
