#ifndef __KNN__
#define __KNN__

#include "utils.c"
#include <math.h>

float dif(int train_index, int test_index, char* type){
    if( type == "PCA" ){
        float cont = 0;
        for(int i=0; i<alpha; i++){
            float temp = train_data[train_index].entry_PCA[i]
                        - test_data[test_index].entry_PCA[i];
            cont += temp*temp;
        }
        return sqrtf(cont);
    }else if( type == "kNN" ){
        int cont = 0;
        for(int i=0; i<entry_size; i++){
            int temp = train_data[train_index].entry[i]
                        - test_data[test_index].entry[i];
            cont += temp*temp;
        }
        return sqrt(cont);
    }

    perror("Type must be PCA or kNN\n");
    exit(EXIT_FAILURE);
}

void kNN(int test_index, int k, float* probabilities, char* type){
    for(int i=0; i<train_size; i++){
        train_data[i].dif_actual = dif(i, test_index-1, type); 
    }
    qsort(train_data, train_size, sizeof(struct info), comp); 

    for(int i=0; i<k; i++){
        probabilities[ train_data[i].value ] += 1.0;
    }
    for(int i=0; i<10; i++) probabilities[i] /= (float)k;
}

#endif	/* !__KNN__ */