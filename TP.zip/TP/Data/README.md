Base de datos original en http://yann.lecun.com/exdb/mnist/

Esta carpeta se organiza en:
	- 60.000 imágenes de entrenamiento (train_entries.txt)
	- 10.000 de testing (test_entries.txt)

Los .txt contiene 60.000 y 10.000 líneas compuestas por 784+1 números. 
El primer número corresponde al dígito que estaba escrito en la imagen. 
Seguidamente se encuentran los 784 números (0-255) que conformarían 
esa imagen de izquierda a derecha, de arriba para abajo.
