#include "../Code/C/utils.c"
#include "../Code/C/defines.h"
#include "../Code/C/kNN.c"
#include "../Code/C/PCA.c"
#include <math.h>
#include <time.h>

/*  
    Para testear una img en particular con PCA en C
    (Fijamos k igual a 5, alpha igual a 160)
    Input: entry_nr
    Output: probability of each digit
*/

int main(){

    int k = 5;
    alpha = 160;
    load_data(train_data, "train");
    load_data(test_data, "test");

    FILE* file = fopen("../../Output/test_entry_PCA_C.txt","w");
    int entry_nr;
    scanf("%d", &entry_nr);

    clock_t start, end;
    start = clock();
    apply_tc();
    end = clock();
    float time = ((float) (end - start)) / CLOCKS_PER_SEC;
    fprintf(file, "Time calculating tc: %0.4f ...\n", time);

    reconstruct_image(entry_nr);
    fprintf(file, "Solving test img nr. %d ...\n\n", entry_nr);
    start = clock();
        
    float probas[10];
    for(int i=0; i<10; i++) probas[i]=0.0;

    kNN(entry_nr, k, probas, "PCA");
    int predic; float proba_predic = -1;
    for(int i=0; i<10; i++){
        fprintf(file, "Proba de ser %d: %0.4f\n", i, probas[i]);
        if( probas[i] > proba_predic ){
                proba_predic = probas[i];
                predic = i;
        } 
    }
    fprintf(file, "\nPrediction: %d\n", predic);
    fprintf(file, "Actual value: %d\n", test_data[entry_nr-1].value);
    end = clock();
    time = ((float) (end - start)) / CLOCKS_PER_SEC;
    fprintf(file, "Time: %.5f", time);

    fclose(file);
    return 0;
}
