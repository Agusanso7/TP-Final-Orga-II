#include "../Code/ASM/utils.c"
#include "../Code/ASM/defines.h"

/*  
    Para reconstruir la imagen asociada a un train_entry
    Input: img_number
    Output: "Xindex_Yvalue.pgm" (donde Y es el numero escrito y X=i)
*/
int main(){

    load_data(test_data, "test");

    int img_number; 
    scanf("%d", &img_number);
    reconstruct_image(img_number);

    return 0;
}
