#include "../Code/ASM/utils.c"
#include "../Code/ASM/defines.h"
#include "../Code/ASM/kNN.c"
#include "../Code/ASM/PCA.c"
#include <math.h>
#include <time.h>

/*  
    Testing de PCA en ASM

    Output: para cada alpha = {4, 16, 40, 160, 400}
    testeamos toda la base de entrenamiento. Para cada alpha se
    imprime en test_PCA_ASM.txt el accuracy y el tiempo (en segundos).
    Habíamos fijado k=5 como valor conveniente.
*/

int main(){
    clock_t start, end;

    load_data(train_data, "train");
    load_data(test_data, "test");

    FILE* file = fopen("../../Output/test_PCA_ASM.txt","w");
    fprintf(file, "k alpha accuracy seg\n");
    
    int k = 5;
    int alphas[5] = {4, 16, 40, 160, 400};
    for(int i=0; i<5; i++){
        alpha = alphas[i];
        start = clock();
        apply_tc();
        float probas[10];
        int tests = test_size;
        int oks = 0;
        for(int test_img=1; test_img<=tests; test_img++){
            for(int i=0; i<10; i++) probas[i]=0.0;
            kNN(test_img, k, probas, "PCA");
            int predic = -1; float proba_predic = -1;
            for(int i=0; i<10; i++){
                if( probas[i] > proba_predic ){
                        proba_predic = probas[i];
                        predic = i;
                } 
            }
            if(predic == test_data[test_img-1].value) oks++;
        }
        end = clock();
        float time = ((float) (end - start)) / CLOCKS_PER_SEC;
        fprintf(file, "%d %d %0.5f %0.4f\n", k, alpha, (float)oks/tests, time);
    }
    fprintf(file, "%d", 0);
    fclose(file);
    return 0;
}
