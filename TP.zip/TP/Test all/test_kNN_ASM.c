#include "../Code/ASM/utils.c"
#include "../Code/ASM/defines.h"
#include "../Code/ASM/kNN.c"
#include <math.h>
#include <time.h>

/*  
    Testing de kNN en ASM

    Output: para cada k = {2, 5, 20, 50, 200, 500, 2000, 5000}
    testeamos toda la base de entrenamiento. Para cada k se
    imprime en test_kNN_ASM.txt el accuracy y el tiempo en segundos.
*/

int main(){
    
    load_data(train_data, "train");
    load_data(test_data, "test");

    FILE* file = fopen("../../Output/test_kNN_ASM.txt","w");

    fprintf(file, "k accuracy seconds\n");
    clock_t start, end;
    int ks[8] = {2, 5, 20, 50, 200, 500, 2000, 5000};
    for(int i=0; i<8; i++){ printf("%d\n", i);//
        int k = ks[i];
        start = clock();
        float probas[10];
        int tests = test_size;
        int oks = 0;
        for(int test_img=1; test_img<=tests; test_img++){
            for(int i=0; i<10; i++) probas[i]=0.0;
            kNN(test_img, k, probas, "kNN"); 
            int predic = -1; float proba_predic = -1;
            for(int i=0; i<10; i++){
                if( probas[i] > proba_predic ){
                    proba_predic = probas[i];
                    predic = i;
                }
            }
            if(predic == test_data[test_img-1].value) oks++;
        }
        end = clock();
        float time = ((float) (end - start)) / CLOCKS_PER_SEC;
        fprintf(file, "%d %0.5f %0.4f\n", k, (float)oks/tests, time);
    }
    fprintf(file, "%d", 0);
    fclose(file);
    return 0;
}
