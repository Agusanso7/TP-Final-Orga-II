#include "../Code/C/utils.c"
#include "../Code/C/defines.h"
#include "../Code/C/kNN.c"
#include <math.h>
#include <time.h>

/*  
    Testing de kNN en C

    Output: para cada k = {2, 5, 20, 50, 200, 500, 2000, 5000}
    testeamos toda la base de entrenamiento. Para cada k se
    imprime el accuracy y el tiempo en segundos.
*/

int main(){
    
    load_data(train_data, "train");
    load_data(test_data, "test");

    printf("k accuracy seconds\n");
    clock_t start, end;
    int ks[8] = {2, 5, 20, 50, 200, 500, 2000, 5000};
    for(int i=/*0*/1; i</*8*/2; i++){
        int k = ks[i];
        start = clock();
        float probas[10];
        int tests = test_size;
        int oks = 0;
        for(int test_img=1; test_img<=tests; test_img++){
            for(int i=0; i<10; i++) probas[i]=0.0;
            kNN(test_img, k, probas, "kNN"); 
            int predic = -1; float proba_predic = -1;
            for(int i=0; i<10; i++){
                if( probas[i] > proba_predic ){
                    proba_predic = probas[i];
                    predic = i;
                }
            }
            if(predic == test_data[test_img-1].value) oks++;
        }
        end = clock();
        float time = ((float) (end - start)) / CLOCKS_PER_SEC;
	printf("%d %0.5f %0.4f\n", k, (float)oks/tests, time);
    }
    printf("%d", 0);
    return 0;
}
